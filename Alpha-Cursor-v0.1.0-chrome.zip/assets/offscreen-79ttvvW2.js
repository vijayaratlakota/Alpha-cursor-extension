const e={RECOGNIZE:"OCR_RECOGNIZE"},s="src/offscreen/index.html";export{e as O,s as a};
